package processor.memorysystem;

public class CacheLine{

	public int[] data;
	public int tag;
	public CacheLine()
	{
		data = new int[1];
		tag = 11111;
	}
}


